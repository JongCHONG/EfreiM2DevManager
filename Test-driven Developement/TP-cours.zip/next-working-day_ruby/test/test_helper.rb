# frozen_string_literal: true

$LOAD_PATH.unshift File.expand_path("../lib", __dir__)
require "working_days_test.rb"

require "minitest/autorun"
