require 'minitest/autorun'
require_relative '../lib/main'

class WorkingDayCalculatorTest < Minitest::Test
  def setup
    @french_calendar = CalendarSystems::FrenchCalendar.new
    @swedish_calendar = CalendarSystems::SwedishCalendar.new
  end
  
  def test_french_weekend
    friday = Date.new(2024, 1, 5)
    result = 2.weeks.after(friday).with_calendar(@french_calendar).next_working_day.to_date
    assert_equal Date.new(2024, 1, 22), result
  end
  
  def test_french_summer_closure
    july_end = Date.new(2024, 7, 31)
    result = DatePoint.new(july_end, @french_calendar).next_working_day.to_date
    assert_equal Date.new(2024, 8, 22), result  # First day after summer closure
  end
  
  def test_swedish_midsummer
    june_start = Date.new(2024, 6, 1)
    result = 2.weeks.after(june_start).with_calendar(@swedish_calendar).next_working_day.to_date
    # Should skip midsummer period
    refute_includes (Date.new(2024, 6, 21)..Date.new(2024, 6, 24)), result
  end
  
  def test_chaining_with_different_calendars
    start_date = Date.new(2024, 12, 20)
    french_result = 2.weeks.after(start_date).with_calendar(@french_calendar).next_working_day.to_date
    swedish_result = 2.weeks.after(start_date).with_calendar(@swedish_calendar).next_working_day.to_date
    refute_equal french_result, swedish_result  # Should be different due to different holiday periods
  end
end
