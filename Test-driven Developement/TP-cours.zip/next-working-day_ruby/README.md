# Working Days Calculator Kata

## Context
A company operates in both France and Sweden. They need to calculate delivery dates for their services, but each country has different working patterns, holidays, and vacation periods.
Initial Requirements
Create a system that determines the next working day after a given date, considering:

Regular weekends
Public holidays
Company vacation periods

## Specific Rules

### France

Weekends: Saturday-Sunday off
Notable holidays: Multiple holidays in May

### Sweden

Different weekend pattern: Works Saturday mornings

- Midsummer celebrations (around June 21st)
- Extended Christmas holiday
- Flexible summer holiday system

## Starting Point

### Start with simple cases first:

- Handle basic weekends
- Add public holidays
- Include vacation periods

## Goal

The exercise focuses on creating clean, readable code that handles complex business rules while maintaining an elegant API. Think about how to make date calculations expressive and maintainable.
Would you like me to add any additional details or clarify any part of the kata description?



# Next::Working::Day

Welcome to your new gem! In this directory, you'll find the files you need to be able to package up your Ruby library into a gem. Put your Ruby code in the file `lib/next/working/day`. To experiment with that code, run `bin/console` for an interactive prompt.

TODO: Delete this and the text above, and describe your gem

## Installation

Add this line to your application's Gemfile:

```ruby
gem 'next-working-day'
```

And then execute:

    $ bundle install

Or install it yourself as:

    $ gem install next-working-day

## Usage

TODO: Write usage instructions here

## Development

After checking out the repo, run `bin/setup` to install dependencies. Then, run `rake test` to run the tests. You can also run `bin/console` for an interactive prompt that will allow you to experiment.

To install this gem onto your local machine, run `bundle exec rake install`. To release a new version, update the version number in `version.rb`, and then run `bundle exec rake release`, which will create a git tag for the version, push git commits and the created tag, and push the `.gem` file to [rubygems.org](https://rubygems.org).

## Contributing

Bug reports and pull requests are welcome on GitHub at https://github.com/[USERNAME]/next-working-day.
