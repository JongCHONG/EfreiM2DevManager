require 'date'
require 'time'

# Extending Integer for fluent date handling (weeks, days, after)
class Integer
  def weeks
    self * 7
  end
  
  def days
    self
  end
  
  def after(date)
    DatePoint.new(date + self)
  end
end

# Calendar systems for different countries
module CalendarSystems
  class BaseCalendar
    def working_day?(date)
      !weekend?(date) && !holiday?(date) && !vacation_period?(date)
    end
    
    protected
    
    def weekend?(date)
      raise NotImplementedError
    end
    
    def holiday?(date)
      raise NotImplementedError
    end
    
    def vacation_period?(date)
      raise NotImplementedError
    end
  end
  
  class FrenchCalendar < BaseCalendar
    WEEKEND_DAYS = [0, 6].freeze  # Sunday and Saturday

    # Months
    JANUARY   = 1
    MAY       = 5
    JULY      = 7
    AUGUST    = 8
    NOVEMBER  = 11
    DECEMBER  = 12

    # Special dates
    NEW_YEARS_DAY    = 1
    LABOR_DAY        = 1  # May
    VICTORY_DAY      = 8  # May
    VICTORY_BRIDGE   = 9  # May
    BASTILLE_DAY     = 14 # July
    BASTILLE_BRIDGE  = 15 # July
    ASSUMPTION_DAY   = 15 # August
    ALL_SAINTS_DAY   = 1  # November
    ARMISTICE_DAY    = 11 # November
    CHRISTMAS_DAY    = 25 # December

    # Summer closure
    SUMMER_CLOSURE_START = 1
    SUMMER_CLOSURE_END   = 21

    def weekend?(date)
      WEEKEND_DAYS.include?(date.wday)
    end
    
    def holiday?(date)
      french_holidays(date.year).include?(date)
    end
    
    def vacation_period?(date)
      summer_closure?(date)
    end
    
    private
    
    def french_holidays(year)
      [
        Date.new(year, JANUARY, NEW_YEARS_DAY),    # New Year's Day
        Date.new(year, MAY, LABOR_DAY),           # Labor Day
        Date.new(year, MAY, VICTORY_DAY),         # Victory Day
        Date.new(year, JULY, BASTILLE_DAY),       # Bastille Day
        Date.new(year, AUGUST, ASSUMPTION_DAY),    # Assumption Day
        Date.new(year, NOVEMBER, ALL_SAINTS_DAY),  # All Saints Day
        Date.new(year, NOVEMBER, ARMISTICE_DAY),   # Armistice Day
        Date.new(year, DECEMBER, CHRISTMAS_DAY),   # Christmas
        # Add "pont" days
        Date.new(year, MAY, VICTORY_BRIDGE),      # Bridge after Victory Day
        Date.new(year, JULY, BASTILLE_BRIDGE)     # Bridge after Bastille Day
      ]
    end
    
    def summer_closure?(date)
      date.month == AUGUST && 
        date.day >= SUMMER_CLOSURE_START && 
        date.day <= SUMMER_CLOSURE_END
    end
  end
  
  class SwedishCalendar < BaseCalendar
    # Days of week
    SUNDAY = 0
    SATURDAY = 6
    AFTERNOON_HOUR = 12

    # Months
    JANUARY = 1
    MAY = 5
    JUNE = 6
    DECEMBER = 12

    # Special dates
    NEW_YEARS_DAY = 1
    EPIPHANY = 6
    LABOR_DAY = 1  # May
    NATIONAL_DAY = 6  # June
    MIDSUMMER_START = 19  # June
    CHRISTMAS_EVE = 24
    CHRISTMAS_DAY = 25
    BOXING_DAY = 26
    NEW_YEARS_EVE = 31

    # Periods
    MIDSUMMER_VICINITY_DAYS = 3
    CHRISTMAS_PERIOD_START = 23
    NEW_YEAR_PERIOD_END = 7

    def weekend?(date)
      case date
      when DateTime, Time
        date.wday == SUNDAY || (date.wday == SATURDAY && date.hour >= AFTERNOON_HOUR)
      when Date
        date.wday == SUNDAY || date.wday == SATURDAY
      end
    end
    
    def holiday?(date)
      swedish_holidays(date.year).include?(date)
    end
    
    def vacation_period?(date)
      christmas_period?(date) || midsummer_period?(date)
    end
    
    private
    
    def swedish_holidays(year)
      [
        Date.new(year, JANUARY, NEW_YEARS_DAY),     # New Year's Day
        Date.new(year, JANUARY, EPIPHANY),          # Epiphany
        Date.new(year, MAY, LABOR_DAY),             # Labor Day
        Date.new(year, JUNE, NATIONAL_DAY),         # National Day
        midsummer_eve(year),                        # Midsummer Eve (Friday between June 19-25)
        Date.new(year, DECEMBER, CHRISTMAS_EVE),    # Christmas Eve
        Date.new(year, DECEMBER, CHRISTMAS_DAY),    # Christmas Day
        Date.new(year, DECEMBER, BOXING_DAY),       # Boxing Day
        Date.new(year, DECEMBER, NEW_YEARS_EVE)     # New Year's Eve
      ]
    end
    
    def midsummer_eve(year)
      date = Date.new(year, JUNE, MIDSUMMER_START)
      date += 1 until date.friday?
      date
    end
    
    def christmas_period?(date)
      (date.month == DECEMBER && date.day >= CHRISTMAS_PERIOD_START) || 
        (date.month == JANUARY && date.day <= NEW_YEAR_PERIOD_END)
    end
    
    def midsummer_period?(date)
      midsummer = midsummer_eve(date.year)
      (date - midsummer).abs <= MIDSUMMER_VICINITY_DAYS
    end
  end
end

# DatePoint for fluent interface
class DatePoint
  def initialize(date, calendar = CalendarSystems::FrenchCalendar.new)
    @date = date
    @calendar = calendar
  end
  
  def next_working_day
    next_date = @date + 1
    next_date += 1 until @calendar.working_day?(next_date)
    DatePoint.new(next_date, @calendar)
  end
  
  def to_date
    @date
  end
  
  def with_calendar(calendar)
    DatePoint.new(@date, calendar)
  end
end

