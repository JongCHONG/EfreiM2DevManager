Feature: Sudoku Solving

  Scenario: Successfully verify a valid, partially completed Sudoku
    Given a valid Sudoku grid with some numbers missing
    When the solver attempts to solve the Sudoku
    Then the Sudoku is solved successfully
    And each row, column, and 3x3 subgrid contains all numbers from 1 to 9

Feature: Detect Unsolvable Sudoku

  Scenario: Detect a Sudoku puzzle that cannot be solved
    Given a Sudoku grid with numbers placed in a way that violates Sudoku rules
    When the solver attempts to solve the Sudoku
    Then the solver identifies the Sudoku as unsolvable

Feature: Validate Completed Sudoku

  Scenario: Validate a completely filled Sudoku grid
    Given a completely filled Sudoku grid
    When the solver checks the validity of the Sudoku
    Then the solver confirms whether the Sudoku is correctly solved or not

Feature: Solve Sudoku with Multiple Solutions

  Scenario: Handle a Sudoku puzzle that has multiple valid solutions
    Given a Sudoku grid that allows multiple solutions
    When the solver attempts to solve the Sudoku
    Then the solver provides at least one valid solution

Feature: Solve Hard Sudoku

  Scenario: Successfully solve a Sudoku classified as hard
    Given a Sudoku grid classified as hard difficulty with many numbers missing
    When the solver attempts to solve the Sudoku
    Then the Sudoku is solved successfully
    And the solution adheres to standard Sudoku rules
