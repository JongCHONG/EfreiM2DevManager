import { describe, expect, it } from 'vitest'

type Movie = { title: string; year: number; };
type Movies = Movie[];

describe('Movie collection search', () => {
  const MOVIE_COLLECTION = [
    {
      title: "The Matrix",
      year: 1999,
    },
    {
      title: "A beautiful mind",
      year: 2001,
    },
    {
      title: "Intouchable",
      year: 2011,
    },
    {
      title: "Forest Gump",
      year: 1994,
    },
  ]; 
  it(`should return empty list when search a movie that is not inside the collection`, () => {
    const moviesFound = findByTitle('Interstellar')(MOVIE_COLLECTION);
    expect(moviesFound).toHaveLength(0);
  });
  it(`should found "The Matrix" when it's query and in the collection`, () => {
    const moviesFound = findByTitle('The Matrix')(MOVIE_COLLECTION);
    expect(moviesFound).toStrictEqual([{
        title: "The Matrix",
        year: 1999,
    }]);
  });
  it('should return all movies containing an "o" in the title', () => {
    const moviesFound = findByTitle('o')(MOVIE_COLLECTION);
    expect(moviesFound).toStrictEqual([
      {
        title: "Intouchable",
        year: 2011,
      },
      {
        title: "Forest Gump",
        year: 1994,
      },
    ]);
  });
});

const isInfixOf: (title: string) => (whole: string) => boolean = title => whole => whole.includes(title);

const filter: <T>(predicate: (item: T) => boolean) => (items: T[]) => T[] = predicate => items => items.filter(predicate);

const compose: <A, B, C>(f: (b: B) => C) => (g: (a: A) => B) => (x: A) => C = f => g => x => f(g(x));

const getTitle: (movie: Movie) => string = movie => movie.title;

/// DOMAIN ----

const matches: (title: string) => (movie: Movie) => boolean = title => compose<Movie, string, boolean>(isInfixOf(title))(getTitle);

const findByTitle: (title: string) => (movies: Movies) => Movies = compose<string, (item: Movie) => boolean, (collection: Movies) => Movies>(filter)(matches);
