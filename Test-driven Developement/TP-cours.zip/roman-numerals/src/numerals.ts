export function sum(a: number, b: number) {
  return a + b
}

const romanNumeralsConverter: Map<number, string> = new Map([
  [1000, 'M'],
  [900, 'CM'],
  [500, 'D'],
  [400, 'CD'],
  [100, 'C'],
  [90, 'XC'],
  [50, 'L'],
  [40, 'XL'],
  [10, 'X'],
  [9, 'IX'],
  [5, 'V'],
  [4, 'IV'],
  [1, 'I'],
]);

export function convertArabicToRomanNumerals(arabic: number): string {
  let roman = "";

  for (const [arabicNumber, romanNumber] of romanNumeralsConverter.entries()) {
    while (arabic >= arabicNumber) {
      roman += romanNumber;
      arabic -= arabicNumber
    }
  }

  return roman;
}
