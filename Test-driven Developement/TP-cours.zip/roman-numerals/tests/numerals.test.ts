import { describe, expect, test, it } from 'vitest'
import { convertArabicToRomanNumerals, sum } from '../src/numerals'

test('adds 1 + 2 to equal 3', () => {
  expect(sum(1, 2)).toBe(3)
})

describe("convert number to Roman numerals", () => {
  it("should return I when parsing 1", () => {
    const candidate = convertArabicToRomanNumerals(1);
    expect(candidate).toBe('I');
  });
  it("should return II when parsing 2", () => {
    const candidate = convertArabicToRomanNumerals(2);
    expect(candidate).toBe('II');
  });
  it("should return III when parsing 3", () => {
    const candidate = convertArabicToRomanNumerals(3);
    expect(candidate).toBe('III');
  });

  it("should return V when parsing 5", () => {
    const candidate = convertArabicToRomanNumerals(5);
    expect(candidate).toBe('V');
  });
  it("should return VI when parsing 6", () => {
    const candidate = convertArabicToRomanNumerals(6);
    expect(candidate).toBe('VI');
  });
  it("should return X when parsing 10", () => {
    const candidate = convertArabicToRomanNumerals(10);
    expect(candidate).toBe('X');
  });
  it("should return XX when parsing 20", () => {
    const candidate = convertArabicToRomanNumerals(20);
    expect(candidate).toBe('XX');
  });
  it("should return XXVII when parsing 27", () => {
    const candidate = convertArabicToRomanNumerals(27);
    expect(candidate).toBe('XXVII');
  });
  it("should return IV when parsing 4", () => {
    const candidate = convertArabicToRomanNumerals(4);
    expect(candidate).toBe('IV');
  });
  it("should return CMXCIX when parsing 999", () => {
    const candidate = convertArabicToRomanNumerals(999);
    expect(candidate).toBe('CMXCIX');
  });
  it("should return XL when parsing 40", () => {
    const candidate = convertArabicToRomanNumerals(40);
    expect(candidate).toBe('XL');
  });
  it("should return MDCCXXXI when parsing 1730", () => {
    const candidate = convertArabicToRomanNumerals(1731);
    expect(candidate).toBe('MDCCXXXI');
  });
});

