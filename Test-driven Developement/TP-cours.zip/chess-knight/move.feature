Feature: Knight Movement

  Scenario: Move knight to a valid empty square
    Given a chessboard with a knight at "b1"
    When the player moves the knight to "c3"
    Then the move is successful
    And the knight is at "c3"

Feature: Knight Capture Move

  Scenario: Knight captures an opponent's piece
    Given a chessboard with a knight at "g1"
    And an opponent's pawn at "e2"
    When the player moves the knight to "e2"
    Then the move is successful
    And the knight is at "e2"
    And the opponent's pawn is removed from the board

Feature: Knight Movement Blocked

  Rule: A piece cannot move on a square where is a piece of the same color

  Scenario: Knight's move is blocked by a piece of the same color
    Given a chessboard with a knight at "b1"
    And a pawn of the same color at "c3"
    When the player tries to move the knight to "c3"
    Then the move is unsuccessful
    And the knight remains at "b1"
    And the pawn remains at "c3"

Feature: Illegal Knight Movement

  Scenario: Knight tries to move in a straight line
    Given a chessboard with a knight at "b1"
    When the player tries to move the knight to "b3"
    Then the move is unsuccessful
    And the knight remains at "b1"

Feature: Knight Movement to Board Edge

  Rule: A piece cannot go out of the board

  Scenario: Move knight to a square at the edge of the board
    Given a chessboard with a knight at "g1"
    When the player moves the knight to "h3"
    Then the move is successful
    And the knight is at "h3"

Feature: Knight Movement in a situation of check 

  Rule: A piece cannot be moved if the king will be in check 

  Scenario: Move knight to a square at the edge of the board
    Given a chessboard with a knight at "d5"
    And the King is in check behind at "e4"
    And the opponent Queen at "c6"
    When the player tries to move the knight to "c3"
    Then the move is unsuccessful
    And the knight remains at "d5"
