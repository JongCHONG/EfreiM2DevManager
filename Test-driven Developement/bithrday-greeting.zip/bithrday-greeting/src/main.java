import java.util.Random;
new DiceGame(new Random());
public class DiceGame {
  public DiceGame(RandonInstance r) {
    random = r;
  }
    private final Random random;

    public int rollDie() {
        return random.nextInt(6) + 1;
    }

    public static void main(String[] args) {
        DiceGame game = new DiceGame();
        System.out.println("Résultat du lancer de dé : " + game.rollDie());
    }
}
