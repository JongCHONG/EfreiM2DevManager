// import fs from "node:fs/promises";
import fs from "node:fs";

class App {
  static main() {
    let fileName = "./employees.txt";

    try {
      if (fs.existsSync(fileName)) {
        const bytes = fs.readFileSync(fileName);
        let content = bytes.toString().split("\n");

        console.log("Reading file...");
        let flag = true;
        for (let line of content) {
          try {
            if (flag) {
              flag = false;
            } else {
              let cell = line.split(",");
              for (let i = 0; i < cell.length; i++) {
                cell[i] = cell[i].trim();
              }

              if (cell.length == 4) {
                const date = cell[2].split("/");
                if (date.length == 3) {
                  let n = new Date();
                  if (n.getDate() == Number.parseInt(date[0]) && n.getMonth() == Number.parseInt(date[1]) - 1) {
                    App.sendEmail(
                      cell[3],
                      "Joyeux Anniversaire !",
                      "Bonjour " + cell[0] + ",\nJoyeux Anniversaire !\nA bientôt,"
                    );
                  }
                } else {
                  console.error("Cannot read birthdate for " + cell[0] + " " + cell[1]);
                }
              } else {
                console.error("Invalid file format");
              }
            }
          } catch (e) {
            console.log(e);
            console.error("Error reading file '" + fileName + "'");
          }
        }
        console.log("Batch job done.");
      } else {
        throw new Error("Unable to open file '" + fileName + "'");
      }
    } catch (error) {
      console.error("Error reading file '" + fileName + "'");
    }
  }

  static sendEmail(to, title, body) {
    console.log("Sending email to : " + to);
    console.log("Title: " + title);
    console.log("Body: Body\n" + body);
    console.log("-------------------------");
  }
}

App.main();
