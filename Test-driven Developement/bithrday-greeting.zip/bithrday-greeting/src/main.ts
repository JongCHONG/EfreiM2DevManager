// import fs from "node:fs/promises";
import fs from "node:fs";

export function parseContent(filename: string): string[] {
  try {
    if (!fs.existsSync(filename)) {
      throw new Error("Unable to open file '" + filename + "'");
    }
    const bytes = fs.readFileSync(filename);
    console.log("Reading file...");
    return bytes.toString().split("\n");
  }
  catch (error) {
    throw new Error("Error reading file '" + filename + "'");
  }
}

export function isBirthday(dateOfBirth: string): boolean {
  const date = dateOfBirth.split("/");
  let now = new Date();
  return now.getDate() == Number.parseInt(date[0]) && now.getMonth() == Number.parseInt(date[1]) - 1;
}

export class NotificationBuilder {
  private to: string | undefined;
  private title: string | undefined;
  private body: string | undefined;

  constructor(partial: NotificationBuilder) {
    this.to = partial.to;
    this.title = partial.title;
    this.body = partial.body;
  }

  addTitle(title: string) {
    this.title = title;
  }

  addTo(to: string) {
    this.to = to;
  }

  addBody(body: string) {
    this.body = body
  }
}

export function main(notifier: Notifier, filename: string) {
  const content = parseContent(filename);

  const vaidateUser = content.map(line => readUser(line)).filter(user => typeof user.dateOfBirth !== "undefined");
  const userHasBithdayToday = vaidateUser.filter(user => isBirthday(user.dateOfBirth!));
  for (const user of userHasBithdayToday) {

    notifier.notify(
      user.email,
      "Joyeux Anniversaire !",
      "Bonjour " + user.firstName + ",\nJoyeux Anniversaire !\nA bientôt,"
    );
  }
  const invaidateUser = content.map(line => readUser(line)).filter(user => typeof user.dateOfBirth === "undefined");
  for (const user of invaidateUser) {
    console.error(`User is invalid ${user}`);
  }
}

export interface Notifier {
  notify(to: string, title: string, body: string): void;
}

export class EmailNotifier implements Notifier {
  notify(to: string, title: string, body: string): void {
    console.log("Sending email to : " + to);
    console.log("Title: " + title);
    console.log("Body: Body\n" + body);
    console.log("-------------------------");
  }
}

export type User = {
  firstName: string,
  lastName: string,
  dateOfBirth: string | undefined,
  email: string
}

export function readUser(line: string): User {
  let cells = line.split(",").map(cell => cell.trim());

  return {
    firstName: cells[0],
    lastName: cells[1],
    dateOfBirth: cells[2],
    email: cells[3]
  };
}


// main(new EmailNotifier(), "./employees.txt");

