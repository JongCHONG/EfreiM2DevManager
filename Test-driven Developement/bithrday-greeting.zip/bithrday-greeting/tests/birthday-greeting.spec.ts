import { Notifier, User, main, readUser, parseContent } from "../src/main.ts";
import { describe, it, expect } from "vitest";

class SpyNotifier implements Notifier {
  private called = 0;
  notify(to: string, title: string, body: string): void {
    this.called += 1;
  }

  getCalled(): number {
    return this.called;
  }
}

describe("Parse User", () => {
  // it("should parse invalid user", () => {
  //   expect(() => readUser("")).toThrowError("Invalid user");
  // });

  it("should parse valid user", () => {
    const candidateLine = "sacha, ketchum, 21/01/2025, sacha.doe@gmail.com";
    const expectedUser: User = {
      firstName: "sacha",
      lastName: "ketchum",
      dateOfBirth: "21/01/2025",
      email: "sacha.doe@gmail.com"
    };
    expect(readUser(candidateLine)).toEqual(expectedUser);
  });
});

describe("parse file", () => {
  it("when open a file (fixture) I should have some line", () => {
    const candidate = parseContent("tests/fixtures/test.txt");
    expect(candidate.length).toBeGreaterThanOrEqual(5);
  });

  it("when open a file (fixture) I should have some line", () => {
    expect(() => parseContent("tests/fixtures/undefined")).toThrow();
  });
});

describe("Birthday Greeting", () => {
  it("should have been called", () => {
    const notifier = new SpyNotifier();
    expect(notifier.getCalled()).toBe(0);
    main(notifier, "tests/fixtures/test.txt");
    expect(notifier.getCalled()).toBe(1);
  });
});
